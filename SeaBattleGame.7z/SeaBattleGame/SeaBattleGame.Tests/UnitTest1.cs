﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SeaBattleGame.Tests
{
    [TestClass]
    public class MainWindowTests
    {
        [TestMethod]
        public void InitializeGrids_ShouldSetAllCellsToEmpty()
        {
            // Arrange
            var window = new MainWindow();

            // Act
            window.InitializeGrids();

            // Assert
            for (int i = 0; i < 10; i++) // Размер сетки
            {
                for (int j = 0; j < 10; j++)
                {
                    Assert.AreEqual(CellState.Empty, window.GetPlayerCellState(i, j));
                    Assert.AreEqual(CellState.Empty, window.GetComputerCellState(i, j));
                }
            }
        }

        [TestMethod]
        public void PlayerShoot_ShouldUpdateCellStateToHit_WhenCellHasShip()
        {
            // Arrange
            var window = new MainWindow();
            window.InitializeGrids();
            window.SetComputerCellState(0, 0, CellState.Ship);

            // Act
            window.PlayerShoot(new System.Windows.Controls.Button { Tag = new System.Windows.Point(0, 0) }, null);

            // Assert
            Assert.AreEqual(CellState.Hit, window.GetComputerCellState(0, 0));
        }

        [TestMethod]
        public void PlayerShoot_ShouldUpdateCellStateToMiss_WhenCellIsEmpty()
        {
            // Arrange
            var window = new MainWindow();
            window.InitializeGrids();

            // Act
            window.PlayerShoot(new System.Windows.Controls.Button { Tag = new System.Windows.Point(0, 0) }, null);

            // Assert
            Assert.AreEqual(expected: CellState.Miss, window.GetComputerCellState(0, 0));
        }

        [TestMethod]
        public void IsShipDestroyed_ShouldReturnTrue_WhenAllCellsAreHit()
        {
            // Arrange
            var window = new MainWindow();
            window.InitializeGrids();
            window.SetComputerCellState(0, 0, CellState.Hit);
            window.SetComputerCellState(0, 1, CellState.Hit);

            // Act
            bool result = window.IsShipDestroyed(0, 0);

            // Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void IsShipDestroyed_ShouldReturnFalse_WhenNotAllCellsAreHit()
        {
            // Arrange
            var window = new MainWindow();
            window.InitializeGrids();
            window.SetComputerCellState(0, 0, CellState.Hit);
            window.SetComputerCellState(0, 1, CellState.Ship);

            // Act
            bool result = window.IsShipDestroyed(0, 0);

            // Assert
            Assert.IsFalse(result);
        }
    }
}
