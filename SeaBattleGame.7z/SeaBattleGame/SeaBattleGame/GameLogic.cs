﻿namespace SeaBattleGame
{
    public class Cell
    {
        public CellState State { get; set; }
        public bool IsRevealed { get; internal set; }
    }

    public enum CellState
    {
        Empty,  // Пустая клетка
        Ship,   // Клетка с кораблем
        Hit,    // Клетка, в которую попали
        Missed,  // Клетка, в которую промахнулись
        Miss
    }
}

