﻿using System;
using System.Collections.Generic;

namespace SeaBattleGame
{
    public static class BotLogic
    {
        private static Random random = new Random();

        // Метод для случайного размещения кораблей
        public static void PlaceShipsRandomly(Cell[,] grid, List<int> shipSizes)
        {
            foreach (int size in shipSizes)
            {
                bool placed = false;

                while (!placed)
                {
                    int x = random.Next(0, grid.GetLength(0));
                    int y = random.Next(0, grid.GetLength(1));
                    bool isHorizontal = random.Next(2) == 0;

                    if (CanPlaceShip(grid, x, y, size, isHorizontal))
                    {
                        for (int i = 0; i < size; i++)
                        {
                            if (isHorizontal)
                                grid[x, y + i].State = CellState.Ship;
                            else
                                grid[x + i, y].State = CellState.Ship;
                        }
                        placed = true;
                    }
                }
            }
        }

        // Проверка, можно ли разместить корабль
        private static bool CanPlaceShip(Cell[,] grid, int x, int y, int size, bool isHorizontal)
        {
            int gridSize = grid.GetLength(0);

            // Проверяем, что корабль помещается в пределах поля
            if (isHorizontal && (y + size > gridSize)) return false;
            if (!isHorizontal && (x + size > gridSize)) return false;

            // Проверка для соседних клеток
            for (int i = 0; i < size; i++)
            {
                int checkX = isHorizontal ? x : x + i;
                int checkY = isHorizontal ? y + i : y;

                // Проверка самой клетки для размещения корабля
                if (grid[checkX, checkY].State != CellState.Empty)
                    return false;

                // Проверка клеток вокруг
                for (int dx = -1; dx <= 1; dx++)
                {
                    for (int dy = -1; dy <= 1; dy++)
                    {
                        int newX = checkX + dx;
                        int newY = checkY + dy;

                        // Проверяем, чтобы клетки вокруг корабля не выходили за пределы поля
                        if (newX >= 0 && newX < gridSize && newY >= 0 && newY < gridSize)
                        {
                            // Если вокруг корабля есть другой корабль или помеченная клетка, то возвращаем false
                            if (grid[newX, newY].State != CellState.Empty)
                            {
                                return false;
                            }
                        }
                    }
                }
            }

            return true;
        }

        // Метод для случайного выстрела бота
        public static (int, int) MakeRandomShot(Cell[,] playerGrid)
        {
            int gridSize = playerGrid.GetLength(0);
            bool shotMade = false;
            int x = 0, y = 0;

            while (!shotMade)
            {
                x = random.Next(0, gridSize);
                y = random.Next(0, gridSize);

                if (!playerGrid[x, y].IsRevealed)
                {
                    shotMade = true;
                }
            }

            return (x, y);
        }


    }
}
