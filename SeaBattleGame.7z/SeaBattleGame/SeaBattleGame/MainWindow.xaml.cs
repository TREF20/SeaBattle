﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace SeaBattleGame
{
    public partial class MainWindow : Window
    {
        public   const int GridSize = 10;

        public Cell[,] playerGrid = new Cell[GridSize, GridSize];
        public Cell[,] computerGrid = new Cell[GridSize, GridSize];

        public List<int> remainingShips = new List<int> { 4, 3, 3, 2, 2, 2, 1, 1, 1, 1 };
        public int selectedShipSize = 1;
        public bool isPlacingShips = true;

        public MainWindow()
        {
            InitializeComponent();
            InitializeGrids();
            DrawGrids();
        }

        public void InitializeGrids()
        {
            for (int i = 0; i < GridSize; i++)
            {
                for (int j = 0; j < GridSize; j++)
                {
                    playerGrid[i, j] = new Cell { State = CellState.Empty };
                    computerGrid[i, j] = new Cell { State = CellState.Empty };
                }
            }
        }


        public void DrawGrids()
        {
            DrawGrid(PlayerGrid, playerGrid, false);
            DrawGrid(ComputerGrid, computerGrid, true);
        }

        public void DrawGrid(Panel gridPanel, Cell[,] grid, bool isComputerGrid)
        {
            gridPanel.Children.Clear();

            for (int i = 0; i < GridSize; i++)
            {
                for (int j = 0; j < GridSize; j++)
                {
                    Button cellButton = new Button
                    {
                        Tag = new Point(i, j),
                        Background = Brushes.LightGray,
                        BorderBrush = Brushes.Black
                    };

                    if (!isComputerGrid && grid[i, j].State == CellState.Ship)
                    {
                        cellButton.Background = Brushes.DarkGray;
                    }

                    if (isComputerGrid && !isPlacingShips)
                    {
                        cellButton.Click += (sender, e) => PlayerShoot(sender, e);
                    }

                    if (!grid[i, j].IsRevealed)
                    {
                    }
                    else
                    {
                        if (grid[i, j].State == CellState.Hit)
                            cellButton.Background = Brushes.Red;
                        else if (grid[i, j].State == CellState.Miss)
                            cellButton.Background = Brushes.Blue;
                    }

                    gridPanel.Children.Add(cellButton);
                }
            }
        }

        public void PlayerShoot(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            Point point = (Point)button.Tag;
            int x = (int)point.X;
            int y = (int)point.Y;

            if (!computerGrid[x, y].IsRevealed)
            {
                computerGrid[x, y].IsRevealed = true;

                if (computerGrid[x, y].State == CellState.Ship)
                {
                    computerGrid[x, y].State = CellState.Hit;
                    MessageBox.Show("Попадание!");

                    // Проверяем, уничтожен ли корабль
                    if (IsShipDestroyed(computerGrid, x, y))
                    {
                        MessageBox.Show("Корабль уничтожен!");
                    }
                }
                else
                {
                    computerGrid[x, y].State = CellState.Miss;
                    MessageBox.Show("Промах!");
                    BotShoot();
                }

                DrawGrids();
            }
        }


        public void BotShoot()
        {
            var (x, y) = BotLogic.MakeRandomShot(playerGrid);

            playerGrid[x, y].IsRevealed = true;

            if (playerGrid[x, y].State == CellState.Ship)
            {
                playerGrid[x, y].State = CellState.Hit;
                MessageBox.Show($"Бот попал в ваш корабль ({x}, {y})!");
            }
            else
            {
                playerGrid[x, y].State = CellState.Miss;
                MessageBox.Show($"Бот промахнулся ({x}, {y}).");
            }

            DrawGrids();
        }

        public void RandomPlaceShipsButton_Click(object sender, RoutedEventArgs e)
        {
            remainingShips.Clear();
            remainingShips.AddRange(new List<int> { 4, 3, 3, 2, 2, 2, 1, 1, 1, 1 });

            InitializeGrids();
            BotLogic.PlaceShipsRandomly(playerGrid, remainingShips);
            DrawGrids();
        }

        public void StartGameButton_Click(object sender, RoutedEventArgs e)
        {
            isPlacingShips = false;
            remainingShips.Clear();

            List<int> botShips = new List<int> { 4, 3, 3, 2, 2, 2, 1, 1, 1, 1 };
            BotLogic.PlaceShipsRandomly(computerGrid, botShips);

            DrawGrids();
            MessageBox.Show("Игра началась!");
        }

        public void HighlightSurroundingCells(Cell[,] grid, int x, int y)
        {
            int gridSize = grid.GetLength(0);

            for (int i = x - 1; i <= x + 1; i++)
            {
                for (int j = y - 1; j <= y + 1; j++)
                {
                    if (i >= 0 && i < gridSize && j >= 0 && j < gridSize)
                    {
                        if (grid[i, j].State == CellState.Empty && !grid[i, j].IsRevealed)
                        {
                            grid[i, j].State = CellState.Miss;
                            grid[i, j].IsRevealed = true;
                        }
                    }
                }
            }
        }

        public bool IsShipDestroyed(Cell[,] grid, int startX, int startY)
        {
            int gridSize = grid.GetLength(0);

            // Проверка в четырех направлениях, чтобы найти весь корабль
            List<Point> shipCells = new List<Point>();
            Queue<Point> toCheck = new Queue<Point>();
            toCheck.Enqueue(new Point(startX, startY));

            while (toCheck.Count > 0)
            {
                Point p = toCheck.Dequeue();
                int x = (int)p.X, y = (int)p.Y;

                if (x < 0 || x >= gridSize || y < 0 || y >= gridSize)
                    continue;

                if (grid[x, y].State == CellState.Ship || grid[x, y].State == CellState.Hit)
                {
                    Point point = new Point(x, y);
                    if (!shipCells.Contains(point))
                    {
                        shipCells.Add(point);

                        // Добавляем соседние клетки для проверки
                        toCheck.Enqueue(new Point(x + 1, y));
                        toCheck.Enqueue(new Point(x - 1, y));
                        toCheck.Enqueue(new Point(x, y + 1));
                        toCheck.Enqueue(new Point(x, y - 1));
                    }
                }
            }

            // Проверяем, все ли клетки корабля помечены как Hit
            foreach (var cell in shipCells)
            {
                if (grid[(int)cell.X, (int)cell.Y].State != CellState.Hit)
                    return false;
            }

            // Подсвечиваем клетки вокруг уничтоженного корабля
            foreach (var cell in shipCells)
            {
                HighlightSurroundingCells(grid, (int)cell.X, (int)cell.Y);
            }

            return true;
        }

        public void SetComputerCellState(int x, int y, CellState state)
        {
            computerGrid[x, y].State = state;
        }


        public CellState GetPlayerCellState(int x, int y)
        {
            return playerGrid[x, y].State;
        }

        public CellState GetComputerCellState(int x, int y)
        {
            return computerGrid[x, y].State;
        }


        public bool IsShipDestroyed(int startX, int startY)
        {
            // Проверяем, что начальная клетка принадлежит кораблю
            if (computerGrid[startX, startY].State != CellState.Hit)
            {
                return false;
            }

            // Проверка клеток горизонтально
            for (int y = startY; y < GridSize && computerGrid[startX, y].State != CellState.Empty; y++)
            {
                if (computerGrid[startX, y].State == CellState.Ship)
                {
                    return false;
                }
            }
            for (int y = startY - 1; y >= 0 && computerGrid[startX, y].State != CellState.Empty; y--)
            {
                if (computerGrid[startX, y].State == CellState.Ship)
                {
                    return false;
                }
            }

            // Проверка клеток вертикально
            for (int x = startX; x < GridSize && computerGrid[x, startY].State != CellState.Empty; x++)
            {
                if (computerGrid[x, startY].State == CellState.Ship)
                {
                    return false;
                }
            }
            for (int x = startX - 1; x >= 0 && computerGrid[x, startY].State != CellState.Empty; x--)
            {
                if (computerGrid[x, startY].State == CellState.Ship)
                {
                    return false;
                }
            }

            // Если все клетки корабля поражены
            return true;
        }



    }

}
