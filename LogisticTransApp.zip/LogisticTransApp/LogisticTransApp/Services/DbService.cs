﻿using System;
using LogisticTransApp.Models;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;
using System.Linq;

namespace LogisticTransApp.Services
{
    public class DbService
    {
        private readonly string _connectionString = "Server=PC\\SQLEXPRESS;Database=LogisticTransDB;Integrated Security=True;";

        // Метод авторизации: проверка логина/пароля, блокировка, первая авторизация
        public Пользователь Authenticate(string login, string password)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT * FROM Пользователь WHERE Логин = @Login";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Login", login);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                Пользователь user = new Пользователь
                                {
                                    ID_Пользователь = (int)reader["ID_Пользователь"],
                                    Логин = (string)reader["Логин"],
                                    Пароль = (string)reader["Пароль"],
                                    RoleID = (int)reader["RoleID"],
                                    IsBlocked = (bool)reader["IsBlocked"],
                                    LastLoginDate = reader["LastLoginDate"] as DateTime?,
                                    FailedAttempts = (int)reader["FailedAttempts"],
                                    IsFirstLogin = (bool)reader["IsFirstLogin"]
                                };

                                // Проверка блокировки
                                if (user.IsBlocked)
                                {
                                    return null; // Заблокирован
                                }

                                // Проверка месяца без входа
                                if (user.LastLoginDate.HasValue && (DateTime.Now - user.LastLoginDate.Value).TotalDays > 30)
                                {
                                    BlockUser(user.ID_Пользователь);
                                    return null;
                                }

                                // Проверка пароля
                                if (user.Пароль == password) // В реальности используйте хеш (e.g. BCrypt)
                                {
                                    ResetFailedAttempts(user.ID_Пользователь);
                                    UpdateLastLogin(user.ID_Пользователь);
                                    return user;
                                }
                                else
                                {
                                    IncrementFailedAttempts(user.ID_Пользователь);
                                    if (user.FailedAttempts + 1 >= 3)
                                    {
                                        BlockUser(user.ID_Пользователь);
                                    }
                                    return null;
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка БД: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            return null;

            try
            {
                using (var context = new LogisticTransDBEntities1())
                {
                    return context.Пользователь
                        .FirstOrDefault(u => u.Логин == login && u.Пароль == password);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка авторизации: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
        }

        // Инкремент неудачных попыток
        private void IncrementFailedAttempts(int userId)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                string query = "UPDATE Пользователь SET FailedAttempts = FailedAttempts + 1 WHERE ID_Пользователь = @Id";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", userId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // Сброс неудачных попыток
        private void ResetFailedAttempts(int userId)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                string query = "UPDATE Пользователь SET FailedAttempts = 0 WHERE ID_Пользователь = @Id";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", userId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // Обновление даты последнего входа
        private void UpdateLastLogin(int userId)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                string query = "UPDATE Пользователь SET LastLoginDate = GETDATE() WHERE ID_Пользователь = @Id";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", userId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // Блокировка пользователя
        private void BlockUser(int userId)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                string query = "UPDATE Пользователь SET IsBlocked = 1 WHERE ID_Пользователь = @Id";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", userId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // Смена пароля
        public bool ChangePassword(int userId, string currentPass, string newPass)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                string query = "UPDATE Пользователь SET Пароль = @NewPass, IsFirstLogin = 0 WHERE ID_Пользователь = @Id AND Пароль = @CurrentPass";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", userId);
                    cmd.Parameters.AddWithValue("@CurrentPass", currentPass);
                    cmd.Parameters.AddWithValue("@NewPass", newPass); // Хеш в реальности
                    int rows = cmd.ExecuteNonQuery();
                    return rows > 0;
                }
            }
        }

        // Получить всех пользователей (для админа)
        public List<Пользователь> GetAllUsers()
        {
            List<Пользователь> users = new List<Пользователь>();
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM Пользователь";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            users.Add(new Пользователь
                            {
                                ID_Пользователь = (int)reader["ID_Пользователь"],
                                Логин = (string)reader["Логин"],
                                Пароль = (string)reader["Пароль"],
                                RoleID = (int)reader["RoleID"],
                                IsBlocked = (bool)reader["IsBlocked"],
                                LastLoginDate = reader["LastLoginDate"] as DateTime?,
                                FailedAttempts = (int)reader["FailedAttempts"],
                                IsFirstLogin = (bool)reader["IsFirstLogin"]
                            });
                        }
                    }
                }
            }
            return users;
        }

        // Добавление пользователя (для админа)
        public bool AddUser(string login, string password, int roleId)
        {
            if (UserExists(login)) return false; // Проверка уникальности
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                string query = "INSERT INTO Пользователь (Логин, Пароль, RoleID) VALUES (@Login, @Pass, @Role)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Login", login);
                    cmd.Parameters.AddWithValue("@Pass", password);
                    cmd.Parameters.AddWithValue("@Role", roleId);
                    cmd.ExecuteNonQuery();
                    return true;
                }
            }
        }

        // Проверка существования пользователя
        private bool UserExists(string login)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM Пользователь WHERE Логин = @Login";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Login", login);
                    return (int)cmd.ExecuteScalar() > 0;
                }
            }
        }

        // Изменение пользователя (для админа, e.g. пароль, роль)
        public void UpdateUser(int userId, string newPassword, int newRoleId)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                string query = "UPDATE Пользователь SET Пароль = @NewPass, RoleID = @NewRole WHERE ID_Пользователь = @Id";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", userId);
                    cmd.Parameters.AddWithValue("@NewPass", newPassword);
                    cmd.Parameters.AddWithValue("@NewRole", newRoleId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // Получить пользователя только по логину (без проверки пароля)
        public Пользователь GetUserByLogin(string login)
        {
            try
            {
                using (var context = new LogisticTransDBEntities1())
                {
                    return context.Пользователь
                        .FirstOrDefault(u => u.Логин == login);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка поиска пользователя: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
        }

        // Снятие блокировки (для админа)
        public void UnlockUser(int userId)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                string query = "UPDATE Пользователь SET IsBlocked = 0, FailedAttempts = 0 WHERE ID_Пользователь = @Id";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", userId);
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}