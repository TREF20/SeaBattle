﻿using System.Windows;
using System.Windows.Controls;
using LogisticTransApp.Models;
using LogisticTransApp.Services;

namespace LogisticTransApp.Forms
{
    public partial class AdminWindow : Window
    {
        private readonly DbService _dbService = new DbService();

        public AdminWindow()
        {
            InitializeComponent();
            LoadUsers();
        }

        private void LoadUsers()
        {
            dgUsers.ItemsSource = _dbService.GetAllUsers();
        }

        private void btnAddUser_Click(object sender, RoutedEventArgs e)
        {
            // Простая форма ввода (можно в отдельном окне, но для простоты MessageBox)
            string login = Microsoft.VisualBasic.Interaction.InputBox("Логин:", "Добавление");
            string pass = Microsoft.VisualBasic.Interaction.InputBox("Пароль:", "Добавление");
            int role = int.Parse(Microsoft.VisualBasic.Interaction.InputBox("RoleID (1-Админ, 2-Польз):", "Добавление"));

            bool added = _dbService.AddUser(login, pass, role);
            if (added)
            {
                MessageBox.Show("Пользователь добавлен.", "Успех");
                LoadUsers();
            }
            else
            {
                MessageBox.Show("Пользователь с таким логином уже существует.", "Ошибка");
            }
        }

        private void btnEditUser_Click(object sender, RoutedEventArgs e)
        {
            if (dgUsers.SelectedItem is Пользователь selected)
            {
                string newPass = Microsoft.VisualBasic.Interaction.InputBox("Новый пароль:", "Изменение");
                int newRole = int.Parse(Microsoft.VisualBasic.Interaction.InputBox("Новый RoleID:", "Изменение"));
                _dbService.UpdateUser(selected.ID_Пользователь, newPass, newRole);
                MessageBox.Show("Изменено.", "Успех");
                LoadUsers();
            }
        }

        private void btnUnlockUser_Click(object sender, RoutedEventArgs e)
        {
            if (dgUsers.SelectedItem is Пользователь selected)
            {
                _dbService.UnlockUser(selected.ID_Пользователь);
                MessageBox.Show("Блокировка снята.", "Успех");
                LoadUsers();
            }
        }
    }
}