﻿using System.Windows;

namespace LogisticTransApp.Forms
{
    public partial class UserWindow : Window
    {
        public UserWindow()
        {
            InitializeComponent();
        }
    }
}