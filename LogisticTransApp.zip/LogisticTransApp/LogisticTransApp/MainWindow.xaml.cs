﻿using LogisticTransApp.Services;
using LogisticTransApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LogisticTransApp.Forms
{
    public partial class MainWindow : Window
    {
        private readonly DbService _dbService = new DbService();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Password.Trim();

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Поля 'Логин' и 'Пароль' обязательны для заполнения. Пожалуйста, заполните их.",
                    "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var user = _dbService.Authenticate(login, password);

            if (user == null)
            {
                // Здесь может быть два случая: неверный пароль ИЛИ пользователь заблокирован
                // Чтобы точно показать сообщение о блокировке, добавим отдельную проверку
                var blockedUser = _dbService.GetUserByLogin(login); // Нужно добавить этот метод в DbService

                if (blockedUser != null && blockedUser.IsBlocked)
                {
                    MessageBox.Show("Вы заблокированы. Обратитесь к администратору.",
                        "Доступ запрещён", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
                else
                {
                    MessageBox.Show("Вы ввели неверный логин или пароль. Пожалуйста, проверьте ещё раз введенные данные.",
                        "Ошибка авторизации", MessageBoxButton.OK, MessageBoxImage.Error);
                }

                return;
            }

            // Успешный вход
            MessageBox.Show("Вы успешно авторизовались. Добро пожаловать!",
                "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

            if (user.IsFirstLogin)
            {
                ChangePasswordWindow changeWindow = new ChangePasswordWindow(user.ID_Пользователь);
                changeWindow.ShowDialog();
            }

            if (user.RoleID == 1) // Администратор
            {
                AdminWindow adminWindow = new AdminWindow();
                adminWindow.Show();
            }
            else
            {
                UserWindow userWindow = new UserWindow();
                userWindow.Show();
            }

            this.Close();
        }
    }
}